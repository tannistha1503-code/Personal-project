# GS26 SSG test cases 5, 6 and 7 — Git Bash

## Files
- `testcase_5.sh`: two 4K random-read jobs at QD32 plus one 4K random-write job at QD1.
- `testcase_6.sh`: 70/30 random read/write mix at QD 1, 4, 16 and 32 (separate runs).
- `testcase_7.sh`: reverse-sequential 4K read versus random 4K read, both QD8.
- `lib/common.sh`: shared precondition, log, fio launch/wait, collection/parser and reset functions.

## Requirements
- Git Bash on Windows; `adb` in PATH; connected Android device.
- `fio` installed on the Android device.
- `python3` installed in Git Bash to parse JSON into CSV.
- Sufficient free space in `/data/local/tmp`.

## Run
```bash
adb devices
chmod +x testcase_5.sh testcase_6.sh testcase_7.sh
RUN_LABEL=setup_A ./testcase_5.sh
RUN_LABEL=setup_A ./testcase_6.sh
RUN_LABEL=setup_A ./testcase_7.sh
```
Repeat under setup B after changing the scheduler/configuration manually. Optional active-scheduler validation:
```bash
EXPECT_SCHED=ssg RUN_LABEL=setup_A ./testcase_5.sh
EXPECT_SCHED=mq-deadline RUN_LABEL=setup_B ./testcase_5.sh
```
If the SSG scheduler name or block device differs, set `EXPECT_SCHED` / `BLOCK_DEV` accordingly. The scripts never change scheduler or cgroup membership automatically.

## Logs
Host folders:
- `logs/testcase_5_logs/<run-tag>/`
- `logs/testcase_6_logs/<run-tag>/`
- `logs/testcase_7_logs/<run-tag>/`

Each has pulled device JSON/text logs and `fio_summary.csv`. Summary includes BW (MiB/s), IOPS, clat p50/p99/p99.9 and max where available. Compare read and write rows separately.

## Test-case interpretation from the sheet
- TC5: compare setup A/B writer clat p99.9/max and reader IOPS. Writer should continue progressing; max write latency target is near or below 5 seconds and should not be worse than setup A.
- TC6: compare read IOPS, write IOPS separately and total IOPS. Total IOPS should remain within 3% across setups; reads should be favoured, while write IOPS should not fall below 70% of setup A at any QD. Treat these as the sheet's stated acceptance criteria.
- TC7: compare read merges, command count and IOPS. Reverse-sequential should benefit from front merges on both setups if front-merge setting is enabled on setup A; random read should show no change.

## Important implementation details / limitations
1. TC5 pre-fills a 2 GiB read file before measurement. The writer uses its own 512 MiB file. All three fio workloads run concurrently.
2. TC6 pre-fills a 2 GiB file, then executes one randrw job at each QD sequentially. It records read and write stats separately.
3. TC7 pre-fills a 1 GiB file. The test sheet's reverse-read notation is `rw=read:-8k`; this is not accepted by every standard fio build and may be a vendor/custom fio extension. The script uses that exact mode by default. If your device fio supports a different reverse-sequential syntax, set it explicitly, e.g. `REVERSE_RW=... ./testcase_7.sh`. Do not silently replace it with ordinary sequential read: that would not test the specified reverse-read case.
4. `reset_test` only removes files under `/data/local/tmp/ssg_gs26/work` and this run's device log folder. It does not erase user data.
5. Runtime defaults to 120 seconds (TC6: 60 seconds per QD). Override using `RUNTIME=...`.
6. The scripts were generated from the provided screenshots but have not been run on your target device. First run with a shorter runtime (`RUNTIME=10`) to validate fio option compatibility and log collection.
