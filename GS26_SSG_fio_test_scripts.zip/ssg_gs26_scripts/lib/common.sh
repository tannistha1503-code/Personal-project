#!/usr/bin/env bash
# Shared helpers for GS26 SSG fio tests. Run from Git Bash on Windows.
# Device-side test files are isolated under /data/local/tmp/ssg_gs26.

ADB="${ADB:-adb}"
DEVICE_DIR="${DEVICE_DIR:-/data/local/tmp/ssg_gs26}"
LOG_ROOT="${LOG_ROOT:-logs}"
RUN_TAG="${RUN_TAG:-$(date +%Y%m%d_%H%M%S)}"
DEVICE_LOG_DIR="$DEVICE_DIR/logs"
HOST_LOG_DIR=""

die() { echo "ERROR: $*" >&2; exit 1; }
log() { echo "[$(date '+%F %T')] $*"; }

adb_ready() {
    command -v "$ADB" >/dev/null 2>&1 || die "adb not found in PATH."
    "$ADB" get-state >/dev/null 2>&1 || die "No adb device in 'device' state."
    "$ADB" shell 'command -v fio >/dev/null 2>&1' >/dev/null 2>&1 || die "fio not found on Android device."
}

adb_sh() { "$ADB" shell "$*"; }

# Record the active scheduler. Set EXPECT_SCHED to require a particular scheduler.
check_scheduler() {
    local dev="${BLOCK_DEV:-sda}" sched
    sched="$(adb_sh "cat /sys/block/$dev/queue/scheduler" 2>/dev/null | tr -d '\r')"
    [ -n "$sched" ] || die "Cannot read scheduler for $dev."
    log "Scheduler ($dev): $sched"
    if [ -n "${EXPECT_SCHED:-}" ] && ! echo "$sched" | grep -Eq "\[$EXPECT_SCHED\]"; then
        die "Expected [$EXPECT_SCHED] to be active. Actual: $sched"
    fi
}

precondition() {
    adb_ready
    adb_sh "mkdir -p '$DEVICE_DIR' '$DEVICE_LOG_DIR' '$DEVICE_DIR/work'" || die "Cannot create device test directory."
    check_scheduler
    local avail
    avail="$(adb_sh "df -k '$DEVICE_DIR' | tail -n 1" | tr -d '\r')"
    log "Device storage: $avail"
    log "Precondition passed."
}

reset_test() {
    # Only remove this suite's own generated files; never clear /data or user files.
    if [ -n "${DEVICE_DIR:-}" ]; then
        adb_sh "pkill -f 'fio.*$DEVICE_DIR/work' 2>/dev/null || true" >/dev/null 2>&1 || true
        adb_sh "rm -rf '$DEVICE_DIR/work' '$DEVICE_LOG_DIR' 2>/dev/null; mkdir -p '$DEVICE_DIR/work' '$DEVICE_LOG_DIR'" >/dev/null 2>&1 || true
    fi
    log "Test reset: stopped suite fio jobs (if any) and cleared only $DEVICE_DIR/work and $DEVICE_LOG_DIR."
}

make_log_dir() {
    local tc="$1"
    HOST_LOG_DIR="$LOG_ROOT/${tc}_logs/$RUN_TAG"
    mkdir -p "$HOST_LOG_DIR" || die "Cannot create $HOST_LOG_DIR"
    adb_sh "mkdir -p '$DEVICE_LOG_DIR/$tc/$RUN_TAG'" || die "Cannot create device log directory."
}

# Create deterministic read data before randread tests. This writes only suite-owned files.
prepare_file() {
    local file="$1" size="$2" logname="$3"
    log "Preparing read file $file ($size); this setup write is excluded from measured fio results."
    adb_sh "fio --name=prepare --filename='$file' --rw=write --bs=1m --size=$size --ioengine=psync --iodepth=1 --direct=1 --end_fsync=1" \
      > "$DEVICE_LOG_DIR/$logname" 2>&1 || die "Could not prepare $file. See device log $logname"
}

# Start one fio process on the device. Arguments: label followed by fio options.
# Each process writes JSON to its own device-side log; stdout/stderr are retained too.
start_fio() {
    local label="$1"; shift
    local json="$DEVICE_LOG_DIR/$TC_NAME/$RUN_TAG/${label}.json"
    local txt="$DEVICE_LOG_DIR/$TC_NAME/$RUN_TAG/${label}.txt"
    local cmd="fio --name=$label $* --output-format=json --output=$json"
    log "Starting $label"
    local pid
    pid="$(adb_sh "sh -c 'nohup $cmd > $txt 2>&1 < /dev/null & echo \\\$!' " | tr -d '\r' | tail -n 1)"
    [[ "$pid" =~ ^[0-9]+$ ]] || die "Could not obtain PID for $label. Device output: $pid"
    eval "PID_${label}='$pid'"
    log "$label PID=$pid"
}

wait_fio() {
    local label="$1" pidvar="PID_$1" pid="${!pidvar:-}"
    [ -n "$pid" ] || die "No PID recorded for $label"
    while adb_sh "kill -0 $pid 2>/dev/null"; do sleep 2; done
    log "$label completed."
}

pull_logs() {
    local tc="$1"
    "$ADB" pull "$DEVICE_LOG_DIR/$tc/$RUN_TAG" "$HOST_LOG_DIR/device_logs" >/dev/null || die "Failed to pull device logs."
}

# Parse fio JSON logs into a common CSV. Reads/writes are handled independently.
# Requires python3 on Git Bash PATH.
parse_fio_logs() {
    local folder="$1"
    command -v python3 >/dev/null 2>&1 || die "python3 is required to parse fio JSON logs."
    python3 - "$folder" <<'PY'
import csv, json, pathlib, sys
root = pathlib.Path(sys.argv[1])
out = root / "fio_summary.csv"
rows = []
for p in sorted(root.rglob("*.json")):
    try:
        obj = json.loads(p.read_text(errors="replace"))
    except Exception as e:
        rows.append([p.name, "PARSE_ERROR", "", "", "", "", "", str(e)])
        continue
    jobs = obj.get("jobs", [])
    for job in jobs:
        for direction in ("read", "write", "trim"):
            d = job.get(direction) or {}
            if not d or not any(k in d for k in ("io_bytes", "bw_bytes", "iops")):
                continue
            clat = d.get("clat_ns") or d.get("clat_us") or d.get("clat_ms") or {}
            unit = "ns" if "clat_ns" in d else ("us" if "clat_us" in d else "ms")
            pct = clat.get("percentile", {})
            def pick(v, obj=pct):
                return obj.get(v, obj.get(str(float(v)), ""))
            bw = d.get("bw_bytes", "")
            if bw != "":
                bw = round(float(bw) / (1024*1024), 3)
            rows.append([
                p.name, job.get("jobname", ""), direction,
                bw, d.get("iops", ""),
                pick("50.000000"), pick("99.000000"), pick("99.900000"),
                unit, d.get("clat_ns", {}).get("max", "")
            ])
            sync = d.get("sync") or {}
            sync_pct = sync.get("lat_ns", {}).get("percentile", {})
            if sync_pct:
                rows.append([
                    p.name, job.get("jobname", ""), direction + "_sync",
                    "", "", sync_pct.get("50.000000", ""),
                    sync_pct.get("99.000000", ""),
                    sync_pct.get("99.900000", ""), "ns",
                    sync.get("lat_ns", {}).get("max", "")
                ])
with out.open("w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["json_log","job","direction","BW_MBps","IOPS","clat_p50","clat_p99","clat_p99_9","latency_unit","clat_max_ns"])
    w.writerows(rows)
print(f"Summary: {out}")
PY
}

finish_test() {
    local tc="$1"
    pull_logs "$tc"
    parse_fio_logs "$HOST_LOG_DIR"
    log "Logs saved in $HOST_LOG_DIR"
}
