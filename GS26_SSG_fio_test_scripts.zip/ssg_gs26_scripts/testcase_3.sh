#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/lib/common.sh"
TC_NAME="testcase_3"
RUN_TAG="${RUN_LABEL:-setup}_${RUN_TAG}"
test_condition() {
  make_log_dir "$TC_NAME"
  prepare_file "$DEVICE_DIR/work/tc3_read_2g.bin" 2g "$TC_NAME/read_file_prepare.txt"
  log "TC3: two noisy 4K randread QD64 jobs + one small 4K randread QD1 job."
  start_fio noisy1 --filename="$DEVICE_DIR/work/tc3_read_2g.bin" --rw=randread --bs=4k --size=2g --ioengine=libaio --iodepth=64 --direct=1 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  start_fio noisy2 --filename="$DEVICE_DIR/work/tc3_read_2g.bin" --rw=randread --bs=4k --size=2g --ioengine=libaio --iodepth=64 --direct=1 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  start_fio small --filename="$DEVICE_DIR/work/tc3_read_2g.bin" --rw=randread --bs=4k --size=2g --ioengine=sync --iodepth=1 --direct=1 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  wait_fio noisy1
  wait_fio noisy2
  wait_fio small
  finish_test "$TC_NAME"
}
precondition
test_condition
reset_test
