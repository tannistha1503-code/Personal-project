# GS26 SSG fio test scripts (Git Bash)

## Package contents
- `testcase_1.sh` – foreground 4K randread QD1 + background 1M sequential direct write QD32.
- `testcase_2.sh` – foreground 4K randread QD1 + background buffered 1M writeback.
- `testcase_3.sh` – two noisy 4K randread QD64 jobs + one small 4K randread QD1 job.
- `testcase_4.sh` – foreground 4K write with `fsync=1` + background buffered 1M bulk write.
- `lib/common.sh` – common precondition, reset, fio launch/wait, log pull and JSON parser.

## Requirements
1. Git Bash on Windows.
2. `adb` available in Git Bash PATH and an Android device visible with `adb devices`.
3. `fio` installed on the Android device.
4. `python3` available in Git Bash PATH (used only to parse fio JSON output).
5. Enough free space under `/data/local/tmp` for test files. The scripts create only their own files under `/data/local/tmp/ssg_gs26`.

## Run
From Git Bash, change to the extracted folder:

```bash
chmod +x *.sh
adb devices
./testcase_1.sh
./testcase_2.sh
./testcase_3.sh
./testcase_4.sh
```

Each script:
1. Checks adb, device-side fio, storage path and active scheduler.
2. Creates/initializes its test data where required.
3. Runs the foreground/background workloads concurrently.
4. Pulls device-side fio JSON and text logs.
5. Generates `fio_summary.csv`.
6. Calls reset to stop leftover suite jobs and remove only suite-owned device work/log files.

## Compare setup A and setup B
Run the same testcase once under each scheduler/configuration, changing the scheduler manually between runs. Do not let the script silently change the scheduler.

```bash
RUN_LABEL=setup_A EXPECT_SCHED=ssg ./testcase_1.sh
RUN_LABEL=setup_B EXPECT_SCHED=mq-deadline ./testcase_1.sh
```

`EXPECT_SCHED` is optional. It checks that the requested scheduler is currently selected in `/sys/block/${BLOCK_DEV:-sda}/queue/scheduler`. The actual scheduler list must contain the name, and it must be active (shown in square brackets). If your kernel exposes a different SSG scheduler name or block device, set the environment variables accordingly.

Example:
```bash
BLOCK_DEV=sda EXPECT_SCHED=ssg RUN_LABEL=SSG ./testcase_3.sh
```

## Logs
Host-side logs are created in separate folders:
- `logs/testcase_1_logs/<run-tag>/`
- `logs/testcase_2_logs/<run-tag>/`
- `logs/testcase_3_logs/<run-tag>/`
- `logs/testcase_4_logs/<run-tag>/`

Each run contains the pulled device logs and `fio_summary.csv`. The JSON is the source of truth; `.txt` files retain fio stdout/stderr.

The summary includes BW (MiB/s), IOPS, clat p50/p99/p99.9 and max where available. For TC4, fio JSON may expose fsync latency under its `sync` statistics; the parser adds a separate `write_sync` row when present. Check the raw JSON if your fio build uses a different JSON schema.

## Important test notes
- TC1: foreground read uses `ioengine=sync`, QD1. Background direct sequential write uses `libaio`, QD32 so QD32 is effective.
- TC2: background buffered write uses `ioengine=psync`, `direct=0`; synchronous engine effectively runs one I/O at a time. This follows the supplied test description.
- TC3: noisy readers use `libaio`, QD64; small reader uses `sync`, QD1. The same prefilled 2 GiB read file is shared, matching the supplied steps.
- TC4: foreground uses `psync`, `fsync=1`, `direct=0`; background uses buffered `psync`, `direct=0`.
- Runtime defaults to 120 seconds. Override with `RUNTIME=60`.
- Fio `--size` specifies the addressable file size for each job; the scripts pre-create read files for TC1–TC3.
- The scripts do not change cgroup membership or scheduler settings. If your test plan requires cgroup placement, do that separately and verify `/dev/blkio/<group>/tasks` or `cgroup.procs`.
- Run each setup at least 3 times and compare matching metrics. Keep device temperature, free space, file state and scheduler configuration consistent.
- `SUCCESS`/`PASS` are not automatically inferred: compare the measurements against the expected-result criteria in your test-case sheet.
