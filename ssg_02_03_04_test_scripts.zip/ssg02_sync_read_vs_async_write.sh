#!/system/bin/sh
# SSG-02: Synchronous read latency vs asynchronous write
# Run as root: sh ssg02_sync_read_vs_async_write.sh [DEVICE_DIR]
# DEVICE_DIR defaults to /data. Pre-create enough free space for both files.

DIR="${1:-/data}"
LOG="$DIR/ssg02_logs"
WRITE_FILE="$DIR/ssg02_async_write.bin"
READ_FILE="$DIR/ssg02_sync_read.bin"
RUNTIME=120
WRITE_SIZE=2G
READ_SIZE=512M
WRITE_BS=512k
READ_BS=4k
WRITE_QD=32
READ_QD=1
PIDS=""

[ "$(id -u)" = "0" ] || { echo "Run as root (su)."; exit 1; }
command -v fio >/dev/null 2>&1 || { echo "fio not found."; exit 1; }
mkdir -p "$LOG" || exit 1

cleanup() {
    for p in $PIDS; do kill "$p" 2>/dev/null; done
}
trap 'cleanup' INT TERM

echo "Preparing files..."
fio --name=prep_write --filename="$WRITE_FILE" --rw=write --bs=1M \
    --size="$WRITE_SIZE" --ioengine=psync --iodepth=1 --direct=1 \
    --output="$LOG/prep_write.log" || exit 1
fio --name=prep_read --filename="$READ_FILE" --rw=write --bs=1M \
    --size="$READ_SIZE" --ioengine=psync --iodepth=1 --direct=1 \
    --output="$LOG/prep_read.log" || exit 1

echo "Starting asynchronous sequential write (libaio, QD=$WRITE_QD)..."
fio --name=async_write --filename="$WRITE_FILE" --rw=write \
    --bs="$WRITE_BS" --iodepth="$WRITE_QD" --ioengine=libaio \
    --direct=1 --time_based --runtime="$RUNTIME" --size="$WRITE_SIZE" \
    --group_reporting --output="$LOG/async_write.log" &
WRITE_PID=$!
PIDS="$PIDS $WRITE_PID"

sleep 2
echo "Starting synchronous random read (psync, QD=$READ_QD)..."
fio --name=sync_read --filename="$READ_FILE" --rw=randread \
    --bs="$READ_BS" --iodepth="$READ_QD" --ioengine=psync \
    --direct=1 --time_based --runtime="$RUNTIME" --size="$READ_SIZE" \
    --group_reporting --output="$LOG/sync_read.log"
READ_STATUS=$?

wait "$WRITE_PID"
WRITE_STATUS=$?
PIDS=""

echo
echo "SSG-02 completed. Read log: $LOG/sync_read.log"
echo "Write log: $LOG/async_write.log"
echo "Check sync-read clat p99 and compare with a read-only baseline."
echo "Exit status: sync_read=$READ_STATUS async_write=$WRITE_STATUS"
exit "$READ_STATUS"
