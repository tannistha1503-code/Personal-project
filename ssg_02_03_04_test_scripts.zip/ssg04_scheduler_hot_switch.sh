#!/system/bin/sh
# SSG-04: Scheduler hot-switch stability under mixed I/O
# Usage:
# sh ssg04_scheduler_hot_switch.sh [SCHEDULER_FILE] [DEVICE_DIR]
# Defaults: /sys/block/sda/queue/scheduler and /data
# Only scheduler names advertised by the scheduler file are used.

SCHED="${1:-/sys/block/sda/queue/scheduler}"
DIR="${2:-/data}"
LOG="$DIR/ssg04_logs"
IO_FILE="$DIR/ssg04_mixed.bin"
RUNTIME=180
SWITCH_COUNT=20
SWITCH_DELAY=2
BS=4k
QD=32
FIO_PID=""
PIDS=""

[ "$(id -u)" = "0" ] || { echo "Run as root (su)."; exit 1; }
command -v fio >/dev/null 2>&1 || { echo "fio not found."; exit 1; }
[ -r "$SCHED" ] && [ -w "$SCHED" ] || {
    echo "Scheduler file is not readable/writable: $SCHED"
    exit 1
}
mkdir -p "$LOG" || exit 1

SUPPORTED=$(cat "$SCHED")
echo "Scheduler file: $SCHED"
echo "Advertised schedulers: $SUPPORTED"

has_scheduler() {
    # Remove brackets around the currently active scheduler before matching.
    echo " $SUPPORTED " | tr '[]' '  ' | grep -q " $1 "
}
for s in ssg mq-deadline none; do
    has_scheduler "$s" || echo "NOTE: '$s' is not advertised; it will be skipped."
done

cleanup() {
    [ -n "$FIO_PID" ] && kill "$FIO_PID" 2>/dev/null
}
trap 'cleanup' INT TERM

echo "Preparing mixed-I/O file..."
fio --name=prep --filename="$IO_FILE" --rw=write --bs=1M \
    --size=2G --ioengine=psync --iodepth=1 --direct=1 \
    --output="$LOG/prep.log" || exit 1

echo "Starting mixed read/write fio workload..."
fio --name=mixed_io --filename="$IO_FILE" --rw=randrw --rwmixread=70 \
    --bs="$BS" --iodepth="$QD" --ioengine=libaio --direct=1 \
    --size=2G --time_based --runtime="$RUNTIME" --group_reporting \
    --output="$LOG/mixed_io.log" &
FIO_PID=$!

sleep 3
echo "Starting scheduler hot-switch loop..."
i=1
while [ "$i" -le "$SWITCH_COUNT" ]; do
    for s in ssg mq-deadline none; do
        if has_scheduler "$s"; then
            echo "Cycle $i: switching to $s"
            if echo "$s" > "$SCHED"; then
                echo "$(date '+%Y-%m-%d %H:%M:%S') cycle=$i scheduler=$s OK" >> "$LOG/scheduler_switch.log"
            else
                echo "$(date '+%Y-%m-%d %H:%M:%S') cycle=$i scheduler=$s FAILED" >> "$LOG/scheduler_switch.log"
                cat "$SCHED" >> "$LOG/scheduler_switch.log"
            fi
            sleep "$SWITCH_DELAY"
        fi
    done
    i=$((i + 1))
done

echo "Switch loop completed. Waiting for fio..."
wait "$FIO_PID"
FIO_STATUS=$?
FIO_PID=""

# Capture kernel messages after the run. Requires dmesg permission.
dmesg > "$LOG/dmesg_after.txt" 2>&1
echo "SSG-04 complete. fio exit status=$FIO_STATUS"
echo "Switch log: $LOG/scheduler_switch.log"
echo "Kernel log snapshot: $LOG/dmesg_after.txt"
echo "Review for panic, hung task, UFS link reset, I/O errors and rejected switches."
exit "$FIO_STATUS"
