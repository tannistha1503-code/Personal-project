SSG test scripts (SSG-02, SSG-03, SSG-04)

Run as root on the Android device. Copy scripts to /data and execute with sh.

SSG-02:
  sh ssg02_sync_read_vs_async_write.sh /data
Runs async sequential write (libaio, QD32) alongside sync random read (psync, QD1).
Inspect sync_read.log p99 clat. Run a read-only baseline for comparison.

SSG-03:
  sh ssg03_cgroup_fairness.sh <GROUP_A_CGROUP_DIR> <GROUP_B_CGROUP_DIR> /data
Requires two EXISTING cgroups with tasks files and either blkio.weight or io.weight.
The script sets equal weight=500, starts 16 independent Group A fio jobs and one Group B job,
and assigns each process's threads to the supplied cgroup. It does not create cgroups.
Check that the weight interface is actually consumed by the SSG scheduler in this kernel.
Equal weights do not by themselves prove an exact 50:50 bandwidth split.

SSG-04:
  sh ssg04_scheduler_hot_switch.sh /sys/block/sda/queue/scheduler /data
Runs mixed randrw I/O while cycling through ssg, mq-deadline and none only if advertised.
Change the scheduler path to the actual UFS block device. Switching schedulers during active
I/O is disruptive; use a test device and stop if errors or instability appear.

All scripts write logs under their respective ssg0X_logs directories.
