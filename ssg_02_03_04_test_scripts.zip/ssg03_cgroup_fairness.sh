#!/system/bin/sh
# SSG-03: Cgroup/thread-group fairness isolation
# Usage:
# sh ssg03_cgroup_fairness.sh <GROUP_A_CGROUP_DIR> <GROUP_B_CGROUP_DIR> [DEVICE_DIR]
#
# Example only if these directories already exist:
# sh ssg03_cgroup_fairness.sh /dev/blkio/groupA /dev/blkio/groupB /data
#
# The script does NOT create cgroups or guess vendor-specific weight controls.
# It requires a tasks file and a supported weight interface in each cgroup.

CG_A="$1"
CG_B="$2"
DIR="${3:-/data}"
LOG="$DIR/ssg03_logs"
SIZE=512M
RUNTIME=120
BS=4k
QD=4
WEIGHT=500
PIDS=""

[ "$(id -u)" = "0" ] || { echo "Run as root (su)."; exit 1; }
command -v fio >/dev/null 2>&1 || { echo "fio not found."; exit 1; }
[ -n "$CG_A" ] && [ -n "$CG_B" ] || {
    echo "Usage: $0 <GROUP_A_CGROUP_DIR> <GROUP_B_CGROUP_DIR> [DEVICE_DIR]"
    exit 1
}
[ -e "$CG_A/tasks" ] || { echo "Missing $CG_A/tasks"; exit 1; }
[ -e "$CG_B/tasks" ] || { echo "Missing $CG_B/tasks"; exit 1; }

weight_file() {
    if [ -e "$1/blkio.weight" ]; then
        echo "$1/blkio.weight"
    elif [ -e "$1/io.weight" ]; then
        echo "$1/io.weight"
    else
        return 1
    fi
}
WA=$(weight_file "$CG_A") || {
    echo "No blkio.weight/io.weight in Group A. Check the SSG cgroup weight interface."
    exit 1
}
WB=$(weight_file "$CG_B") || {
    echo "No blkio.weight/io.weight in Group B. Check the SSG cgroup weight interface."
    exit 1
}

mkdir -p "$LOG" || exit 1
echo "$WEIGHT" > "$WA" || { echo "Cannot set Group A weight: $WA"; exit 1; }
case "$WB" in
    */io.weight) echo "default $WEIGHT" > "$WB" || exit 1 ;;
    *) echo "$WEIGHT" > "$WB" || exit 1 ;;
esac
# cgroup v2 io.weight uses "default N"; cgroup v1 blkio.weight uses N.
case "$WA" in
    */io.weight) echo "default $WEIGHT" > "$WA" || exit 1 ;;
    *) echo "$WEIGHT" > "$WA" || exit 1 ;;
esac

# Verify both configured weights.
echo "Group A weight file: $WA"
cat "$WA"
echo "Group B weight file: $WB"
cat "$WB"

cleanup() {
    for p in $PIDS; do kill "$p" 2>/dev/null; done
}
trap 'cleanup' INT TERM

add_threads() {
    pid="$1"; tasks="$2"; tries=0
    while [ "$tries" -lt 5 ] && [ ! -d "/proc/$pid/task" ]; do
        sleep 1
        tries=$((tries + 1))
    done
    [ -d "/proc/$pid/task" ] || return 1
    for t in /proc/"$pid"/task/*; do
        [ -d "$t" ] || continue
        tid=${t##*/}
        echo "$tid" > "$tasks" || return 1
    done
    for t in /proc/"$pid"/task/*; do
        [ -d "$t" ] || continue
        tid=${t##*/}
        grep -qx "$tid" "$tasks" || return 1
    done
    return 0
}

start_group_job() {
    group="$1"; index="$2"; cgtasks="$3"; file="$4"
    fio --name="${group}_${index}" --filename="$file" --rw=randwrite \
        --bs="$BS" --size="$SIZE" --ioengine=libaio --iodepth="$QD" \
        --direct=1 --time_based --runtime="$RUNTIME" --randrepeat=0 \
        --group_reporting --output="$LOG/${group}_${index}.log" &
    pid=$!
    PIDS="$PIDS $pid"
    add_threads "$pid" "$cgtasks" || {
        echo "Failed to assign $group PID=$pid to $cgroup tasks file."
        cleanup
        exit 1
    }
    echo "$group job $index PID=$pid assigned and verified."
}

echo "Starting 16 jobs in Group A..."
i=1
while [ "$i" -le 16 ]; do
    start_group_job A "$i" "$CG_A/tasks" "$DIR/ssg03_A_$i.bin"
    i=$((i + 1))
done

echo "Starting 1 job in Group B..."
start_group_job B 1 "$CG_B/tasks" "$DIR/ssg03_B_1.bin"

echo "Running for $RUNTIME seconds..."
for p in $PIDS; do
    wait "$p"
done
PIDS=""

echo
echo "SSG-03 complete. Per-job fio logs are in $LOG."
echo "Aggregate Group A bandwidth by summing A_*.log; compare with Group B_1.log."
echo "Equal weights do not guarantee an exact 50:50 bandwidth split; interpret against the SSG implementation and device limits."
