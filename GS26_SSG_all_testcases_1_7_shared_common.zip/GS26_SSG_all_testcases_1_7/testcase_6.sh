#!/usr/bin/env bash
set -euo pipefail
TC_NAME="testcase_6"
source "$(dirname "$0")/lib/common.sh"
test_condition(){
  make_logs
  local rd="$DEVICE_DIR/work/tc6_randrw_2g.bin"
  prepare_read_file "$rd" 2g
  log "TC6: randrw 70/30, 4K, QD 1/4/16/32. Each QD is a separate measured run."
  for qd in 1 4 16 32; do
    log "Starting QD=$qd"
    start_fio "mix_qd${qd}" --filename="$rd" --rw=randrw --rwmixread=70 --bs=4k --iodepth="$qd" --ioengine=libaio --size=2g --time_based=1 --runtime="${RUNTIME:-60}" --direct=1 --group_reporting
    wait_fio "mix_qd${qd}"
  done
  collect_logs
}
precondition
test_condition
reset_test
