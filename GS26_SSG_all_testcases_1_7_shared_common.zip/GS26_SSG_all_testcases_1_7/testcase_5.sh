#!/usr/bin/env bash
set -euo pipefail
TC_NAME="testcase_5"
source "$(dirname "$0")/lib/common.sh"
test_condition(){
  make_logs
  local rd="$DEVICE_DIR/work/tc5_read_2g.bin"
  prepare_read_file "$rd" 2g
  log "TC5: two 4K randread QD32 jobs + one 4K randwrite QD1 job"
  start_fio r1 --filename="$rd" --rw=randread --bs=4k --iodepth=32 --ioengine=libaio --size=2g --time_based=1 --runtime="${RUNTIME:-120}" --direct=1 --group_reporting
  start_fio r2 --filename="$rd" --rw=randread --bs=4k --iodepth=32 --ioengine=libaio --size=2g --time_based=1 --runtime="${RUNTIME:-120}" --direct=1 --group_reporting
  start_fio w --filename="$DEVICE_DIR/work/tc5_write_512m.bin" --rw=randwrite --bs=4k --iodepth=1 --ioengine=psync --size=512m --time_based=1 --runtime="${RUNTIME:-120}" --direct=1 --group_reporting
  wait_fio r1; wait_fio r2; wait_fio w
  collect_logs
}
precondition
test_condition
reset_test
