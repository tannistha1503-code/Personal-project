#!/usr/bin/env bash
set -euo pipefail
TC_NAME="testcase_7"
source "$(dirname "$0")/lib/common.sh"
test_condition(){
  make_logs
  local rd="$DEVICE_DIR/work/tc7_read_1g.bin"
  prepare_read_file "$rd" 1g
  # Test sheet specifies rw=read:-8k for reverse sequential. This may be a
  # vendor/custom fio extension; standard fio builds may reject this syntax.
  local reverse_rw="${REVERSE_RW:-read:-8k}"
  log "TC7: reverse-sequential read versus random 4K read; both use direct I/O and QD8."
  log "Reverse rw mode: $reverse_rw"
  start_fio reverse --filename="$rd" --rw="$reverse_rw" --bs=4k --size=1g --iodepth=8 --ioengine=libaio --direct=1 --time_based=1 --runtime="${RUNTIME:-120}" --group_reporting
  start_fio random --filename="$rd" --rw=randread --bs=4k --size=1g --io_size=256m --iodepth=8 --ioengine=libaio --direct=1 --time_based=1 --runtime="${RUNTIME:-120}" --group_reporting
  wait_fio reverse; wait_fio random
  collect_logs
}
precondition
test_condition
reset_test
