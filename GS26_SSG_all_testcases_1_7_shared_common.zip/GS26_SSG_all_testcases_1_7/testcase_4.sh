#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/lib/common.sh"
TC_NAME="testcase_4"
test_condition() {
  make_logs
  log "TC4: foreground 4K buffered write + fsync after each 4K write, alongside background 1M buffered bulk write."
  # fio's fsync=1 triggers fsync after every write.
  start_fio sync --filename="$DEVICE_DIR/work/tc4_sync_64m.bin" --rw=write --bs=4k --size=64m --ioengine=psync --iodepth=1 --direct=0 --fsync=1 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  start_fio bulk --filename="$DEVICE_DIR/work/tc4_bulk_4g.bin" --rw=write --bs=1m --size=4g --ioengine=psync --iodepth=1 --direct=0 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  wait_fio sync
  wait_fio bulk
  collect_logs
}
precondition
test_condition
reset_test
