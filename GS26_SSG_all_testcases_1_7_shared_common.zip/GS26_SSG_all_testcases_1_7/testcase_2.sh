#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/lib/common.sh"
TC_NAME="testcase_2"
test_condition() {
  make_logs
  prepare_read_file "$DEVICE_DIR/work/tc2_read_1g.bin" 1g
  log "TC2: foreground 4K randread QD1 + background buffered 1M writeback (direct=0, psync)."
  start_fio fg --filename="$DEVICE_DIR/work/tc2_read_1g.bin" --rw=randread --bs=4k --size=1g --ioengine=sync --iodepth=1 --direct=1 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  start_fio bg --filename="$DEVICE_DIR/work/tc2_bg_4g.bin" --rw=write --bs=1m --size=4g --ioengine=psync --iodepth=1 --direct=0 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  wait_fio fg
  wait_fio bg
  collect_logs
}
precondition
test_condition
reset_test
