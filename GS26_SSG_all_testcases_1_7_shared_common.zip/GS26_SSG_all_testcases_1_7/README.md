# GS26 SSG fio test suite — Test Cases 1 to 7 (Git Bash)

All seven test scripts use exactly one shared helper file: `lib/common.sh`.

## Files
- `testcase_1.sh` through `testcase_7.sh`
- `lib/common.sh` — shared precondition, logging, file preparation, fio launch/wait, JSON-to-CSV collection and reset functions.

## Requirements
- Git Bash on Windows.
- `adb` in PATH and Android device in `adb devices`.
- `fio` installed on the Android device.
- `python3` installed in Git Bash for CSV parsing.
- Enough free space under `/data/local/tmp`.

## Run
```bash
adb devices
chmod +x testcase_*.sh
RUNTIME=10 RUN_LABEL=setup_A ./testcase_1.sh
RUNTIME=10 RUN_LABEL=setup_A ./testcase_2.sh
RUNTIME=10 RUN_LABEL=setup_A ./testcase_3.sh
RUNTIME=10 RUN_LABEL=setup_A ./testcase_4.sh
RUNTIME=10 RUN_LABEL=setup_A ./testcase_5.sh
RUNTIME=10 RUN_LABEL=setup_A ./testcase_6.sh
RUNTIME=10 RUN_LABEL=setup_A ./testcase_7.sh
```
Use short runs first to validate command compatibility. Then run the planned full duration.

Optional active scheduler check:
```bash
EXPECT_SCHED=ssg RUN_LABEL=SSG ./testcase_1.sh
EXPECT_SCHED=mq-deadline RUN_LABEL=MQD ./testcase_1.sh
```
Set `BLOCK_DEV=sda` if your UFS block device is sda. The scripts do not change scheduler or cgroup membership.

## Shared common functions
- `precondition()` checks ADB, python3, device-side fio, creates suite directories and records the active scheduler.
- `make_logs()` creates `logs/<testcase>_logs/<run-tag>`.
- `prepare_read_file()` pre-fills read workloads before measurement.
- `start_fio()` and `wait_fio()` start and monitor separate fio processes.
- `collect_logs()` pulls raw JSON/text logs and creates `fio_summary.csv` with BW, IOPS, clat p50/p99/p99.9 and max when present.
- `reset_test()` removes only this suite's `/data/local/tmp/ssg_gs26/work` and this run's device-side log folder.

## Host log layout
```text
logs/
  testcase_1_logs/<run-tag>/
  testcase_2_logs/<run-tag>/
  testcase_3_logs/<run-tag>/
  testcase_4_logs/<run-tag>/
  testcase_5_logs/<run-tag>/
  testcase_6_logs/<run-tag>/
  testcase_7_logs/<run-tag>/
```
Each run has `device_logs/` with JSON and text logs, plus `fio_summary.csv`.

## Workload definitions
- TC1: FG 4K randread QD1 + BG 1M sequential direct write QD32.
- TC2: FG 4K randread QD1 + BG 1M buffered write (`psync`, direct=0).
- TC3: two 4K randread QD64 noisy processes + one 4K randread QD1 small process.
- TC4: FG 4K buffered write with `fsync=1` + BG 1M buffered bulk write.
- TC5: two 4K randread QD32 processes + one 4K randwrite QD1 process.
- TC6: 70/30 4K randrw at QD 1, 4, 16 and 32, one QD per run.
- TC7: reverse sequential 4K read vs random 4K read, QD8.

## Important notes
- TC7 uses the screenshot's `rw=read:-8k` reverse-read notation by default. This may be a vendor/custom fio extension; standard fio may reject it. Do not replace it silently with ordinary sequential read.
- TC4's `fsync=1` asks fio to fsync after every write. Confirm the device fio supports the option.
- The scripts were generated from the provided test-case screenshots but have not been executed on the target device. Validate with short runs first.
- `reset_test()` is called after successful completion. It removes only suite-owned test files and the current run's device logs from the device. Host-side logs are retained.
