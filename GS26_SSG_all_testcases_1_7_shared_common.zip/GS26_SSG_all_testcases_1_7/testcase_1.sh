#!/usr/bin/env bash
set -euo pipefail
source "$(dirname "$0")/lib/common.sh"
TC_NAME="testcase_1"
test_condition() {
  make_logs
  prepare_read_file "$DEVICE_DIR/work/tc1_read_1g.bin" 1g
  log "TC1: foreground 4K randread QD1 + background 1M sequential direct write QD32."
  start_fio fg --filename="$DEVICE_DIR/work/tc1_read_1g.bin" --rw=randread --bs=4k --size=1g --ioengine=sync --iodepth=1 --direct=1 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  start_fio bg --filename="$DEVICE_DIR/work/tc1_bg_2g.bin" --rw=write --bs=1m --size=2g --ioengine=libaio --iodepth=32 --direct=1 --time_based --runtime="${RUNTIME:-120}" --group_reporting
  wait_fio fg
  wait_fio bg
  collect_logs
}
precondition
test_condition
reset_test
