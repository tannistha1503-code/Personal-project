#!/usr/bin/env bash
set -euo pipefail
ADB="${ADB:-adb}"
DEVICE_DIR="${DEVICE_DIR:-/data/local/tmp/ssg_gs26}"
BLOCK_DEV="${BLOCK_DEV:-sda}"
LOG_ROOT="${LOG_ROOT:-logs}"
RUN_TAG="${RUN_LABEL:-run}_$(date +%Y%m%d_%H%M%S)"
TC_NAME="${TC_NAME:-testcase_unknown}"
HOST_LOG_DIR=""
log(){ echo "[$(date '+%F %T')] $*"; }
die(){ echo "ERROR: $*" >&2; exit 1; }
adb_sh(){ "$ADB" shell "$*"; }

precondition(){
  command -v "$ADB" >/dev/null 2>&1 || die "adb not found in PATH"
  command -v python3 >/dev/null 2>&1 || die "python3 required in Git Bash for CSV parsing"
  "$ADB" get-state >/dev/null 2>&1 || die "ADB device is not ready"
  adb_sh 'command -v fio >/dev/null 2>&1' >/dev/null 2>&1 || die "fio not found on Android device"
  adb_sh "mkdir -p '$DEVICE_DIR/work' '$DEVICE_DIR/logs/$TC_NAME/$RUN_TAG'" || die "Cannot create device test folders"
  local sched
  sched="$(adb_sh "cat /sys/block/$BLOCK_DEV/queue/scheduler" 2>/dev/null | tr -d '\r')" || die "Cannot read scheduler"
  log "Active scheduler: $sched"
  if [ -n "${EXPECT_SCHED:-}" ] && ! grep -q "\[$EXPECT_SCHED\]" <<<"$sched"; then
    die "Expected [$EXPECT_SCHED] active; got $sched"
  fi
  log "Precondition passed"
}

make_logs(){
  HOST_LOG_DIR="$LOG_ROOT/${TC_NAME}_logs/$RUN_TAG"
  mkdir -p "$HOST_LOG_DIR"
}

prepare_read_file(){
  local path="$1" size="$2"
  log "Pre-filling $path ($size); preparation is excluded from measured results"
  adb_sh "fio --name=prepare --filename='$path' --rw=write --bs=1m --size=$size --ioengine=psync --iodepth=1 --direct=1 --end_fsync=1" \
    > "$DEVICE_DIR/logs/$TC_NAME/$RUN_TAG/prepare.txt" 2>&1 || die "Read-file preparation failed"
}

start_fio(){
  local label="$1"; shift
  local json="$DEVICE_DIR/logs/$TC_NAME/$RUN_TAG/${label}.json"
  local txt="$DEVICE_DIR/logs/$TC_NAME/$RUN_TAG/${label}.txt"
  local cmd="fio --name=$label $* --output-format=json --output=$json"
  log "Starting $label: $*"
  local pid
  pid="$(adb_sh "sh -c 'nohup $cmd > $txt 2>&1 < /dev/null & echo \\\$!'" | tr -d '\r' | tail -n1)"
  [[ "$pid" =~ ^[0-9]+$ ]] || die "Could not start $label (PID response: $pid). Check device log."
  printf -v "PID_${label}" '%s' "$pid"
  log "$label PID=$pid"
}
wait_fio(){
  local label="$1" var="PID_$1" pid="${!var:-}"
  [ -n "$pid" ] || die "Missing PID for $label"
  while adb_sh "kill -0 $pid 2>/dev/null"; do sleep 2; done
  log "$label completed"
}
collect_logs(){
  "$ADB" pull "$DEVICE_DIR/logs/$TC_NAME/$RUN_TAG" "$HOST_LOG_DIR/device_logs" >/dev/null || die "adb pull failed"
  python3 - "$HOST_LOG_DIR/device_logs" <<'PY'
import csv,json,pathlib,sys
root=pathlib.Path(sys.argv[1]); out=root/"fio_summary.csv"; rows=[]
for p in sorted(root.rglob("*.json")):
 try: obj=json.loads(p.read_text(errors="replace"))
 except Exception as e:
  rows.append([p.name,"PARSE_ERROR","","","","","","",str(e)]); continue
 for j in obj.get("jobs",[]):
  for direction in ("read","write"):
   d=j.get(direction,{})
   if not d or not any(k in d for k in ("io_bytes","bw_bytes","iops")): continue
   c=d.get("clat_ns") or d.get("clat_us") or d.get("clat_ms") or {}
   unit="ns" if "clat_ns" in d else ("us" if "clat_us" in d else "ms")
   pct=c.get("percentile",{})
   def val(n): return pct.get(n,pct.get(str(float(n)),""))
   bw=d.get("bw_bytes","")
   if bw!="": bw=round(float(bw)/1048576,3)
   rows.append([p.name,j.get("jobname",""),direction,bw,d.get("iops",""),
                val("50.000000"),val("99.000000"),val("99.900000"),unit,c.get("max","")])
with out.open("w",newline="") as f:
 w=csv.writer(f); w.writerow(["json_log","job","direction","BW_MiB_s","IOPS","clat_p50","clat_p99","clat_p99_9","unit","clat_max"]); w.writerows(rows)
print("Created",out)
PY
  log "Host logs: $HOST_LOG_DIR"
}
reset_test(){
  # Remove only this suite's work/log directories. No user data or /data is touched.
  adb_sh "pkill -f 'fio.*$DEVICE_DIR/work' 2>/dev/null || true; rm -rf '$DEVICE_DIR/work' '$DEVICE_DIR/logs/$TC_NAME/$RUN_TAG'; mkdir -p '$DEVICE_DIR/work'" >/dev/null 2>&1 || true
  log "Reset complete for suite-owned paths"
}
